import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Process_Log extends JPanel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static ArrayList<Process> paintedProcess = new ArrayList<Process>(); // 37���� �ִ� ������
	public static ArrayList<Integer> paintednum = new ArrayList<Integer>(); // 37���� �ִ� ������
	
	Process_Log() {
		setLayout(null);
		setVisible(true);
	}
	
	
	@Override
	public void paint(Graphics g) {
		g.setColor(Color.white);
		g.fillRect(0, 0, 739, 119);
		g.setColor(Color.BLACK);
		g.drawRect(0, 0, 739, 119);
			
		for(int i=0;i<paintedProcess.size();i++) {
			Process temp2 = paintedProcess.get(i);
			
			g.setColor(Color.white);
			g.setFont(new Font("Arial", Font.BOLD, 10));
			
			if (temp2 != null) { // ��ȿ�� ���μ����̸�
				g.drawImage(Main_Frame.colorImage[temp2.color].getImage(), i*20, 0, 19, 120, null);
				g.drawString("P"+temp2.processNumber, i*20+4, 60);
			} else if (temp2==null) { // null ���μ����̸�(�ƹ��� �������� �ʾ�����)
				g.drawImage(new ImageIcon("image/Black.png").getImage(), i*20, 0, 19, 120, null);
				g.drawString("��", i*20+6, 60);
			}
			g.drawString(String.valueOf(paintednum.get(i)+1), i*20+5, 25);		
		}
	}
}



