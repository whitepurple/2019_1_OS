import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;


public class Hongsam extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Container pane = getContentPane();

	Hongsam() {
		setTitle("Hongsam");
		setSize(600, 400);
		setLocationRelativeTo(null); // �߾� ��ġ�ϱ�
		setResizable(false); // ũ�� ������ �� ���� �ϱ�
		pane.setBackground(new Color(0xa8dba8));
		setLayout(null);
		addWindowListener(new WindowAdapter() { // ������ x ������ �� ������
			public void windowClosing(WindowEvent e) {
				setVisible(false);
				setIgnoreRepaint(true);
			}
		});
		setVisible(false);
	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		
		// 0: ��������, 1: ó������, 2: 3�� �̸�, 3: ����
		// ���º� ���� ����
		int state = Process_Scheduler.hsState;
		g.setFont(new Font("���� ����", Font.BOLD, 20));
		g.setColor(Color.red);
		if (state == 1) { // ó�� ����
			g.drawString("�ƽ�~! ��! ��!", 110, 60);
		} else if (state == 3) {
			g.drawString("�ƽ�~! ��!", 110, 60);
		} else if (state == 0){
			g.drawString("�ƽ�~! ȫ��! �����ٵ� ȫ��!!!!", 110, 60);
			for (int i=0; i<22; i++) {
				g.drawImage(new ImageIcon("image/everybody.png").getImage(), 20+i*26, 330, 25, 50, null);
			}
			for (int i=0; i<6; i++) {
				g.drawImage(new ImageIcon("image/everybody.png").getImage(), 10, 25+i*51, 25, 50, null);
				g.drawImage(new ImageIcon("image/everybody.png").getImage(), 570, 25+i*51, 25, 50, null);
			}
		} else if (state == 2) {
			if (Process_Scheduler.readyQueue.size() ==0 && Process_Scheduler.processInCPU == null) {
				g.drawString("Game Over", 250, 60);
				g.drawImage(new ImageIcon("image/over.png").getImage(), 20, 70, 530, 300, null);
			} else {
				g.drawString("����~~~ Ÿ��~!", 110, 60);
				g.drawImage(new ImageIcon("image/real.png").getImage(), 20, 70, 260, 150, null);
			}
		}
		
		// ���� �׸���
		g.setColor(Color.BLACK);
		Process tailPc1 = Process_Scheduler.hsTail_1;
		Process tailPc2 = Process_Scheduler.hsTail_2;
		Process headPc1 = Process_Scheduler.hsHead_1;
		Process headPc2 = Process_Scheduler.hsHead_2;
	
		if (tailPc1 != null && tailPc2 != null) {
			g.drawLine(tailPc1.loc.x+190+25, tailPc1.loc.y+100+5, headPc1.loc.x+190+25, headPc1.loc.y+100+5);
			g.drawLine(tailPc2.loc.x+190+25, tailPc2.loc.y+100+5, headPc2.loc.x+190+25, headPc2.loc.y+100+5);
			
			if (tailPc1 == headPc1) {
				g.drawOval(tailPc1.loc.x+190+25, tailPc1.loc.y+100+5, 50, 50);
			}
			if (tailPc2 == headPc2) {
				g.drawOval(tailPc2.loc.x+190+25, tailPc2.loc.y+100+5, 50, 50);
			}
		}
		
		
		// ���μ��� �׸���
		for (int i=0; i<Process_Scheduler.readyQueue.size(); i++) {
			Process temp = Process_Scheduler.readyQueue.get(i); // �ϳ��� ����ť���� �޾ƿ��鼭
			if (temp.color == 0) {
			 g.setColor(Color.RED);
            } else if (temp.color == 1) {
           	 g.setColor(Color.ORANGE);
            } else if (temp.color == 2) {
           	 g.setColor(Color.yellow);
            } else if (temp.color == 3) {
           	 g.setColor(Color.green);
            } else if (temp.color == 4) {
           	 g.setColor(Color.cyan);
            } else if (temp.color == 5) {
           	 g.setColor(Color.blue);
            } else if (temp.color == 6) {
           	 g.setColor(Color.magenta);
            }
				
			g.fillOval(temp.loc.x+190, temp.loc.y+80, 50, 50);
			g.setColor(Color.WHITE);
			g.setFont(new Font("Arial", Font.BOLD , 15));
			g.drawString("P"+temp.processNumber,temp.loc.x+205 , temp.loc.y+110);
		}
		if (headPc1 != null && headPc2 != null) {
			g.drawImage(new ImageIcon("image/hong.png").getImage(), headPc1.loc.x+215, headPc1.loc.y+105, 50, 50, null);
			g.drawImage(new ImageIcon("image/hong.png").getImage(), headPc2.loc.x+215, headPc2.loc.y+105, 50, 50, null);
		}
		
	}
}
