
public class Main {

	public static void main(String[] args) {
		@SuppressWarnings("unused")
		Main_Frame main = new Main_Frame();
	}

}