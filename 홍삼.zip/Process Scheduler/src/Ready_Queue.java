import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JPanel;

public class Ready_Queue extends JPanel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Ready_Queue() {
		setLayout(null);
		setVisible(true);
	}
	
	@Override
	public void paint(Graphics g) {	
		g.setColor(Color.white);
		g.fillRect(0, 0, 739, 49);
		g.setColor(Color.BLACK);
		g.drawRect(0, 0, 739, 49);
		
		for(int i=0;i<Process_Scheduler.readyQueue.size();i++) { // ����ť ��� ���μ����� ��ȸ�ϸ鼭
			Process temp = Process_Scheduler.readyQueue.get(i);
			
			if (temp.hongsam) { // ȫ�� ���� ����� ���μ����� �ȱ׸�
				temp.hongsam = false;
				continue;
			}
			
			g.drawImage(Main_Frame.colorImage[temp.color].getImage(), i*50, 0, 49, 50, null); // ���μ��� �׸�
			g.setColor(Color.black);
			g.setFont(new Font("Arial", Font.PLAIN, 15));
			g.drawString("P"+temp.processNumber, i*50+10, 25);
		}
	}
}
